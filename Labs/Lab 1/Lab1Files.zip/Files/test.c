/* test.c */
#include <stdlib.h>
#include <stdio.h>

int main(){
    printf ("%s","Hello World\n");
    exit (EXIT_SUCCESS);
}
