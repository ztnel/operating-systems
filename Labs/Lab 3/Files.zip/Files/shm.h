//Physical memory organization
struct shared_use_st {
    int rnd;
};