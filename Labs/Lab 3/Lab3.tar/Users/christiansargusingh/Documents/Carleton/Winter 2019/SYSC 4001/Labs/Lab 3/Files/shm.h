#define SIZE 2048

struct shared_use_st {
    int rnd;
};